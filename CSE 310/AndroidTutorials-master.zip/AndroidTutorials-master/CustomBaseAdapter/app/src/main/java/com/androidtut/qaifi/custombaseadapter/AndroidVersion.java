package com.androidtut.qaifi.custombaseadapter;

/**
 * Created by Qaifi on 2/20/2018.
 */

public class AndroidVersion {
    private double versionNum;
    private String versionName;

    public double getVersionNum() {
        return versionNum;
    }

    public void setVersionNum(double versionNum) {
        this.versionNum = versionNum;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }
}
